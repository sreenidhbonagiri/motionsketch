import { cloneActor, coerceActor } from '../actor'
import {
  clampStageAspect,
  LEGACY_STAGE_ASPECT,
} from '../stageAspect'
import {
  compositionSizeFromAspect,
  MAX_STAGE_COMPOSITION_EDGE,
  MIN_STAGE_COMPOSITION_EDGE,
  resolveProjectStageSize,
  withProjectStageSize,
} from '../stageResize'
import {
  cloneSceneActor,
  createSceneActor,
  MAX_ACTORS,
  migrateLegacyProjectToActors,
  parseSceneActor,
  projectHasAnyRecording,
} from '../sceneActor'
import { emptyTransformTrack, parseTransformTrack } from '../transform'
import {
  DEFAULT_PROJECT_NAME,
  sanitizeProjectName,
} from '../projectName'
import { coercePlaybackTrigger, isPlaybackTrigger } from '../export/triggers'
import {
  DEFAULT_PLAYBACK,
  DEFAULT_STAGE_ASPECT,
  MAX_PLAYBACK_DURATION_MS,
  MIN_PLAYBACK_DURATION_MS,
  type ActorImage,
  type GeometryEdit,
  type LoopMode,
  type PlaybackSettings,
  type Project,
  type SceneActor,
} from '../types'

/**
 * Envelope version for localStorage / download files.
 * v1–v4: single-actor project (migrated to one SceneActor).
 * v5: multi-actor + shared timeline; image assets may be deduped.
 * v6: per-actor clip timing (start/end on shared timeline).
 * v7: project.name (older files migrate to “Untitled project”).
 * v8: clip.hideBeforeStart / clip.hideAfterEnd (older → both off).
 * v9: geometryEdit.handleIndices (older → evenly spaced defaults).
 * v10: playback.trigger (older → page-load; export activation only).
 * v11: actor.faceAlongPath / directionOffsetDeg (older → off / 0°).
 * v12: actor.glide (older → 0).
 * v13: appearance.text + kind 'text' (older → text null; kind unchanged).
 * v14: project.stageWidth / stageHeight composition units (older → derive from
 *      stageAspect with default height 1000 so appearance is unchanged).
 *
 * Additive (no version bump): geometryEdit.timingBaked / restoreSteadySpeed /
 * restoreGlide — older files omit them (treated as unset / not timing-baked).
 */
export const PERSIST_FORMAT_VERSION = 14 as const
export const PERSIST_FORMAT_VERSION_LEGACY = 1 as const
export const PERSIST_FORMAT_VERSION_V2 = 2 as const
export const PERSIST_FORMAT_VERSION_V3 = 3 as const
export const PERSIST_FORMAT_VERSION_V4 = 4 as const
export const PERSIST_FORMAT_VERSION_V5 = 5 as const
export const PERSIST_FORMAT_VERSION_V6 = 6 as const
export const PERSIST_FORMAT_VERSION_V7 = 7 as const
export const PERSIST_FORMAT_VERSION_V8 = 8 as const
export const PERSIST_FORMAT_VERSION_V9 = 9 as const
export const PERSIST_FORMAT_VERSION_V10 = 10 as const
export const PERSIST_FORMAT_VERSION_V11 = 11 as const
export const PERSIST_FORMAT_VERSION_V12 = 12 as const
export const PERSIST_FORMAT_VERSION_V13 = 13 as const

export const STORAGE_KEY = 'motionsketch.project.v1'

/** Soft cap for serialized project JSON (localStorage + downloads). */
export const MAX_PROJECT_JSON_CHARS = 4_500_000

export interface PersistedSnapshot {
  formatVersion: typeof PERSIST_FORMAT_VERSION
  savedAt: string
  project: Project
  /**
   * Deduplicated image payloads referenced by appearance.image via matching
   * dataUrl. Present in downloads when any actor uses an image.
   */
  assets?: Record<string, ActorImage>
}

export type PersistParseOk = { ok: true; snapshot: PersistedSnapshot }
export type PersistParseErr = { ok: false; error: string }
export type PersistParseResult = PersistParseOk | PersistParseErr

export function buildSnapshot(
  project: Project,
  _geometryEditIgnored: GeometryEdit | null = null,
  savedAt: string = new Date().toISOString(),
): PersistedSnapshot {
  const cloned = cloneProject(project)
  const { project: wired, assets } = extractSharedAssets(cloned)
  return {
    formatVersion: PERSIST_FORMAT_VERSION,
    savedAt,
    project: wired,
    ...(Object.keys(assets).length > 0 ? { assets } : {}),
  }
}

export function serializeSnapshot(snapshot: PersistedSnapshot): string {
  // Always rebuild so shared images are deduped into `assets`.
  return serializeSnapshotForDownload(snapshot)
}

export function parseSnapshotJson(raw: string): PersistParseResult {
  if (raw.length > MAX_PROJECT_JSON_CHARS) {
    return {
      ok: false,
      error: `Project file is too large (max ${Math.round(MAX_PROJECT_JSON_CHARS / 1024)} KB).`,
    }
  }
  let data: unknown
  try {
    data = JSON.parse(raw) as unknown
  } catch {
    return { ok: false, error: 'File is not valid JSON.' }
  }
  return validateSnapshot(data)
}

export function validateSnapshot(data: unknown): PersistParseResult {
  if (!isRecord(data)) {
    return { ok: false, error: 'Project data must be an object.' }
  }

  if (!('formatVersion' in data)) {
    return { ok: false, error: 'Missing formatVersion.' }
  }

  if (typeof data.formatVersion !== 'number' || !Number.isFinite(data.formatVersion)) {
    return { ok: false, error: 'Invalid formatVersion.' }
  }

  const formatVersion = data.formatVersion
  const supported = [
    PERSIST_FORMAT_VERSION,
    PERSIST_FORMAT_VERSION_V13,
    PERSIST_FORMAT_VERSION_V12,
    PERSIST_FORMAT_VERSION_V11,
    PERSIST_FORMAT_VERSION_V10,
    PERSIST_FORMAT_VERSION_V9,
    PERSIST_FORMAT_VERSION_V8,
    PERSIST_FORMAT_VERSION_V7,
    PERSIST_FORMAT_VERSION_V6,
    PERSIST_FORMAT_VERSION_V5,
    PERSIST_FORMAT_VERSION_V4,
    PERSIST_FORMAT_VERSION_V3,
    PERSIST_FORMAT_VERSION_V2,
    PERSIST_FORMAT_VERSION_LEGACY,
  ]
  if (!supported.includes(formatVersion as typeof PERSIST_FORMAT_VERSION)) {
    return {
      ok: false,
      error: `Unsupported project format version ${formatVersion}. This app supports versions ${PERSIST_FORMAT_VERSION_LEGACY}–${PERSIST_FORMAT_VERSION}.`,
    }
  }

  if (typeof data.savedAt !== 'string' || data.savedAt.length === 0) {
    return { ok: false, error: 'Missing or invalid savedAt.' }
  }

  const assets = parseAssets(data.assets)
  if (!assets.ok) return assets

  // v5–v8 multi-actor (v5 migrates missing clip; v7 name; v8 visibility flags).
  if (formatVersion >= PERSIST_FORMAT_VERSION_V5) {
    const project = validateMultiActorProject(
      data.project,
      assets.value,
      formatVersion,
    )
    if (!project.ok) return project
    // Reject leftover top-level geometryEdit that would be ignored silently.
    if (data.geometryEdit != null) {
      return {
        ok: false,
        error:
          'Multi-actor projects store path edits on each actor; unexpected top-level geometryEdit.',
      }
    }
    return {
      ok: true,
      snapshot: {
        formatVersion: PERSIST_FORMAT_VERSION,
        savedAt: data.savedAt,
        project: project.value,
        ...(Object.keys(assets.value).length > 0
          ? { assets: assets.value }
          : {}),
      },
    }
  }

  // v1–v4 single-actor migration
  const legacy = validateLegacyProject(data.project, formatVersion)
  if (!legacy.ok) return legacy

  let geometryEdit: GeometryEdit | null = null
  if (data.geometryEdit != null) {
    const ge = validateLegacyGeometryEdit(data.geometryEdit)
    if (!ge.ok) return ge
    if (!legacy.value.recording) {
      return { ok: false, error: 'geometryEdit requires a recording.' }
    }
    geometryEdit = ge.value
  }

  const actor = migrateLegacyProjectToActors({
    actor: legacy.value.actor,
    recording: legacy.value.recording,
    playback: legacy.value.playback,
    transform: legacy.value.transform,
    geometryEdit,
  })

  const stageAspect = legacy.value.stageAspect
  const migratedSize = compositionSizeFromAspect(stageAspect)
  return {
    ok: true,
    snapshot: {
      formatVersion: PERSIST_FORMAT_VERSION,
      savedAt: data.savedAt,
      project: {
        version: 1,
        name: DEFAULT_PROJECT_NAME,
        actors: [actor],
        playback: {
          durationMs: legacy.value.playback.durationMs,
          loop: legacy.value.playback.loop,
          loopMode: legacy.value.playback.loopMode,
          trigger: coercePlaybackTrigger(
            (legacy.value.playback as { trigger?: unknown }).trigger,
          ),
        },
        stageAspect,
        stageWidth: migratedSize.width,
        stageHeight: migratedSize.height,
      },
    },
  }
}

function parseAssets(
  value: unknown,
): { ok: true; value: Record<string, ActorImage> } | PersistParseErr {
  if (value === undefined || value === null) {
    return { ok: true, value: {} }
  }
  if (!isRecord(value)) {
    return { ok: false, error: 'assets must be an object.' }
  }
  const out: Record<string, ActorImage> = {}
  for (const [id, asset] of Object.entries(value)) {
    if (typeof id !== 'string' || id.length === 0) {
      return { ok: false, error: 'assets keys must be non-empty strings.' }
    }
    const coerced = coerceActor({ kind: 'image', image: asset, width: 0.12 })
    if (!coerced.image) {
      return { ok: false, error: `assets[${id}] is not a valid image.` }
    }
    out[id] = { ...coerced.image }
  }
  return { ok: true, value: out }
}

function parseProjectName(
  value: unknown,
  formatVersion: number,
): { ok: true; value: string } | PersistParseErr {
  if (value === undefined || value === null) {
    // Pre-v7 files migrate to a stable default without changing animation data.
    if (formatVersion < PERSIST_FORMAT_VERSION) {
      return { ok: true, value: DEFAULT_PROJECT_NAME }
    }
    return { ok: false, error: 'project.name is required.' }
  }
  if (typeof value !== 'string') {
    return { ok: false, error: 'project.name must be a string.' }
  }
  const name = sanitizeProjectName(value)
  if (name.length === 0) {
    return { ok: false, error: 'project.name must be a non-empty string.' }
  }
  return { ok: true, value: name }
}

function validateMultiActorProject(
  value: unknown,
  assets: Record<string, ActorImage>,
  formatVersion: number,
): { ok: true; value: Project } | PersistParseErr {
  if (!isRecord(value)) {
    return { ok: false, error: 'Missing or invalid project.' }
  }
  if (value.version !== 1) {
    return {
      ok: false,
      error:
        typeof value.version === 'number'
          ? `Unsupported project.version ${value.version}.`
          : 'Missing or invalid project.version.',
    }
  }

  const name = parseProjectName(value.name, formatVersion)
  if (!name.ok) return name

  const playback = validatePlayback(value.playback)
  if (!playback.ok) return playback

  const stageAspect = coerceStageAspect(value.stageAspect, formatVersion)
  if (!stageAspect.ok) return stageAspect

  const stageSize = coerceStageSize(
    value.stageWidth,
    value.stageHeight,
    stageAspect.value,
    formatVersion,
  )
  if (!stageSize.ok) return stageSize

  if (!Array.isArray(value.actors)) {
    return { ok: false, error: 'project.actors must be an array.' }
  }
  if (value.actors.length === 0) {
    return { ok: false, error: 'project.actors must contain at least one actor.' }
  }
  if (value.actors.length > MAX_ACTORS) {
    return {
      ok: false,
      error: `project.actors has ${value.actors.length} entries; maximum is ${MAX_ACTORS}.`,
    }
  }

  const actors: SceneActor[] = []
  const seenIds = new Set<string>()
  for (let i = 0; i < value.actors.length; i++) {
    const rawActor = value.actors[i]
    // Resolve imageAssetId before parseSceneActor if present.
    const resolved = resolveActorAppearance(rawActor, assets, i)
    if (!resolved.ok) return resolved
    const parsed = parseSceneActor(resolved.value, i)
    if (!parsed.ok) return parsed
    if (seenIds.has(parsed.value.id)) {
      return {
        ok: false,
        error: `Duplicate actor id “${parsed.value.id}”.`,
      }
    }
    seenIds.add(parsed.value.id)
    actors.push(parsed.value)
  }

  return {
    ok: true,
    value: {
      version: 1,
      name: name.value,
      actors,
      playback: playback.value,
      stageAspect: stageSize.value.aspect,
      stageWidth: stageSize.value.width,
      stageHeight: stageSize.value.height,
    },
  }
}

function resolveActorAppearance(
  value: unknown,
  assets: Record<string, ActorImage>,
  index: number,
): { ok: true; value: unknown } | PersistParseErr {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    return { ok: false, error: `actors[${index}] must be an object.` }
  }
  const actor = { ...(value as Record<string, unknown>) }
  const appearanceRaw = actor.appearance
  if (typeof appearanceRaw !== 'object' || appearanceRaw === null) {
    return { ok: true, value: actor }
  }
  const appearance = { ...(appearanceRaw as Record<string, unknown>) }
  const image = appearance.image
  if (typeof image === 'object' && image !== null && !Array.isArray(image)) {
    const img = image as Record<string, unknown>
    if (typeof img.assetId === 'string') {
      const asset = assets[img.assetId]
      if (!asset) {
        return {
          ok: false,
          error: `actors[${index}] references missing assets[${img.assetId}].`,
        }
      }
      appearance.image = { ...asset }
      actor.appearance = appearance
    }
  }
  return { ok: true, value: actor }
}

interface LegacyProject {
  actor: unknown
  recording: Project['actors'][0]['recording']
  playback: PlaybackSettings & { smoothing: number; steadySpeed: number }
  stageAspect: number
  transform: Project['actors'][0]['transform']
}

function validateLegacyProject(
  value: unknown,
  formatVersion: number,
): { ok: true; value: LegacyProject } | PersistParseErr {
  if (!isRecord(value)) {
    return { ok: false, error: 'Missing or invalid project.' }
  }
  if (value.version !== 1) {
    return {
      ok: false,
      error:
        typeof value.version === 'number'
          ? `Unsupported project.version ${value.version}.`
          : 'Missing or invalid project.version.',
    }
  }

  const recording = validateLegacyRecording(value.recording)
  if (!recording.ok) return recording

  const playback = validateLegacyPlayback(value.playback)
  if (!playback.ok) return playback

  const stageAspect = coerceStageAspect(value.stageAspect, formatVersion)
  if (!stageAspect.ok) return stageAspect

  const transform = parseTransformTrack(value.transform)
  if (!transform.ok) return transform

  return {
    ok: true,
    value: {
      actor: value.actor,
      recording: recording.value,
      playback: playback.value,
      stageAspect: stageAspect.value,
      transform: transform.value,
    },
  }
}

function validateLegacyRecording(
  value: unknown,
): { ok: true; value: LegacyProject['recording'] } | PersistParseErr {
  // Reuse scene actor parser via a shim
  const shim = parseSceneActor(
    {
      id: 'legacy',
      name: 'Actor 1',
      appearance: { kind: 'shape', width: 0.12, height: 0.12, borderRadius: 0, color: '#000', image: null },
      recording: value,
      transform: { keyframes: [] },
    },
    0,
  )
  if (!shim.ok) {
    return {
      ok: false,
      error: shim.error.replace(/^actors\[0\]\.recording/, 'recording'),
    }
  }
  return { ok: true, value: shim.value.recording }
}

function validateLegacyPlayback(
  value: unknown,
): { ok: true; value: LegacyProject['playback'] } | PersistParseErr {
  const base = validatePlayback(value)
  if (!base.ok) return base
  if (!isRecord(value)) {
    return { ok: false, error: 'Invalid playback.' }
  }
  const smoothing =
    typeof value.smoothing === 'number' && Number.isFinite(value.smoothing)
      ? clamp01(value.smoothing)
      : 0.35
  const steadySpeed =
    typeof value.steadySpeed === 'number' && Number.isFinite(value.steadySpeed)
      ? clamp01(value.steadySpeed)
      : 0
  return {
    ok: true,
    value: {
      ...base.value,
      smoothing,
      steadySpeed,
    },
  }
}

function validateLegacyGeometryEdit(
  value: unknown,
): { ok: true; value: GeometryEdit } | PersistParseErr {
  const shim = parseSceneActor(
    {
      id: 'legacy',
      name: 'Actor 1',
      appearance: DEFAULT_SHAPE_APPEARANCE,
      recording: null,
      geometryEdit: value,
      transform: emptyTransformTrack(),
    },
    0,
  )
  // parseSceneActor allows null recording with geometryEdit — tighten:
  if (typeof value !== 'object' || value === null) {
    return { ok: false, error: 'Invalid geometryEdit.' }
  }
  const actorLike = parseSceneActor(
    {
      id: 'legacy',
      name: 'A',
      appearance: DEFAULT_SHAPE_APPEARANCE,
      recording: {
        recordedDurationMs: 100,
        samples: [
          { t: 0, x: 0.2, y: 0.2 },
          { t: 100, x: 0.8, y: 0.8 },
        ],
      },
      geometryEdit: value,
      transform: emptyTransformTrack(),
    },
    0,
  )
  if (!actorLike.ok || !actorLike.value.geometryEdit) {
    return {
      ok: false,
      error:
        !actorLike.ok
          ? actorLike.error.replace(/^actors\[0\]\.geometryEdit/, 'geometryEdit')
          : 'Invalid geometryEdit.',
    }
  }
  void shim
  return { ok: true, value: actorLike.value.geometryEdit }
}

const DEFAULT_SHAPE_APPEARANCE = {
  kind: 'shape' as const,
  width: 0.12,
  height: 0.12,
  borderRadius: 0.28,
  color: '#4f46e5',
  image: null,
}

function validatePlayback(
  value: unknown,
): { ok: true; value: PlaybackSettings } | PersistParseErr {
  if (!isRecord(value)) {
    return { ok: false, error: 'Missing or invalid playback.' }
  }
  const durationMs = asFiniteNumber(value.durationMs)
  if (
    durationMs === null ||
    durationMs < MIN_PLAYBACK_DURATION_MS ||
    durationMs > MAX_PLAYBACK_DURATION_MS
  ) {
    return {
      ok: false,
      error: `playback.durationMs must be in [${MIN_PLAYBACK_DURATION_MS}, ${MAX_PLAYBACK_DURATION_MS}].`,
    }
  }
  if (typeof value.loop !== 'boolean') {
    return { ok: false, error: 'playback.loop must be a boolean.' }
  }
  const loopMode = coerceLoopMode(value.loopMode)
  // Missing trigger (v1–v9) → page-load. Present but invalid → reject import.
  if (value.trigger !== undefined && value.trigger !== null) {
    if (!isPlaybackTrigger(value.trigger)) {
      return {
        ok: false,
        error:
          'playback.trigger must be one of: page-load, click, hover, viewport.',
      }
    }
  }
  const trigger = coercePlaybackTrigger(value.trigger)
  return {
    ok: true,
    value: {
      durationMs: Math.round(durationMs),
      loop: value.loop,
      loopMode,
      trigger,
    },
  }
}

function coerceLoopMode(value: unknown): LoopMode {
  return value === 'alternate' ? 'alternate' : 'repeat'
}

/**
 * v14+: require finite, positive stageWidth/stageHeight in range; aspect must
 * match width/height (otherwise reject). Older: migrate missing sizes from
 * aspect × default height. When older files include both sizes but aspect
 * disagrees, dimensions win (aspect rewritten to width/height).
 */
function coerceStageSize(
  widthRaw: unknown,
  heightRaw: unknown,
  stageAspect: number,
  formatVersion: number,
):
  | { ok: true; value: { width: number; height: number; aspect: number } }
  | PersistParseErr {
  const hasWidth = widthRaw !== undefined && widthRaw !== null
  const hasHeight = heightRaw !== undefined && heightRaw !== null

  if (!hasWidth && !hasHeight) {
    if (formatVersion >= PERSIST_FORMAT_VERSION) {
      return {
        ok: false,
        error: 'project.stageWidth and project.stageHeight are required.',
      }
    }
    // Pre-v14 files: derive composition size from aspect (appearance unchanged).
    const size = compositionSizeFromAspect(stageAspect)
    return {
      ok: true,
      value: {
        width: size.width,
        height: size.height,
        aspect: clampStageAspect(stageAspect),
      },
    }
  }

  if (!hasWidth || !hasHeight) {
    return {
      ok: false,
      error:
        'project.stageWidth and project.stageHeight must both be present when either is set.',
    }
  }

  if (typeof widthRaw !== 'number' || typeof heightRaw !== 'number') {
    return {
      ok: false,
      error: 'project.stageWidth and project.stageHeight must be numbers.',
    }
  }
  const width = asFiniteNumber(widthRaw)
  const height = asFiniteNumber(heightRaw)
  if (width === null || height === null) {
    return {
      ok: false,
      error: 'project.stageWidth and project.stageHeight must be finite numbers.',
    }
  }
  if (!(width > 0) || !(height > 0)) {
    return {
      ok: false,
      error: 'project.stageWidth and project.stageHeight must be positive.',
    }
  }
  const w = Math.round(width)
  const h = Math.round(height)
  if (
    w < MIN_STAGE_COMPOSITION_EDGE ||
    h < MIN_STAGE_COMPOSITION_EDGE ||
    w > MAX_STAGE_COMPOSITION_EDGE ||
    h > MAX_STAGE_COMPOSITION_EDGE
  ) {
    return {
      ok: false,
      error: `project.stageWidth/stageHeight must be in [${MIN_STAGE_COMPOSITION_EDGE}, ${MAX_STAGE_COMPOSITION_EDGE}].`,
    }
  }
  const fromSize = clampStageAspect(w / h)
  const aspectMismatch =
    Math.abs(fromSize - clampStageAspect(stageAspect)) > 1e-3
  if (aspectMismatch && formatVersion >= PERSIST_FORMAT_VERSION) {
    return {
      ok: false,
      error:
        'project.stageAspect does not match project.stageWidth / stageHeight.',
    }
  }
  // Pre-v14 with both sizes: dimensions are authoritative (deterministic).
  return {
    ok: true,
    value: { width: w, height: h, aspect: fromSize },
  }
}

function coerceStageAspect(
  value: unknown,
  formatVersion: number,
): { ok: true; value: number } | PersistParseErr {
  if (value === undefined || value === null) {
    if (formatVersion <= PERSIST_FORMAT_VERSION_LEGACY) {
      return { ok: true, value: LEGACY_STAGE_ASPECT }
    }
    return { ok: true, value: LEGACY_STAGE_ASPECT }
  }
  const n = asFiniteNumber(value)
  if (n === null || n <= 0) {
    return { ok: false, error: 'project.stageAspect must be a positive number.' }
  }
  return { ok: true, value: clampStageAspect(n) }
}

function extractSharedAssets(project: Project): {
  project: Project
  assets: Record<string, ActorImage>
} {
  const assets: Record<string, ActorImage> = {}
  const urlToId = new Map<string, string>()
  let n = 0

  const actors = project.actors.map((actor) => {
    const appearance = cloneActor(actor.appearance)
    if (appearance.kind === 'image' && appearance.image) {
      const url = appearance.image.dataUrl
      let id = urlToId.get(url)
      if (!id) {
        n += 1
        id = `img-${n}`
        urlToId.set(url, id)
        assets[id] = { ...appearance.image }
      }
      // Keep full image in memory snapshot project for runtime; assets map
      // carries deduped payloads for the file. Wire format uses assetId only
      // in JSON via replacer below — here we stash assetId on a clone for serialize.
      ;(appearance as ActorWithAssetRef).image = {
        ...appearance.image,
        assetId: id,
      } as ActorImage & { assetId: string }
    }
    return { ...cloneSceneActor(actor), appearance }
  })

  return { project: { ...project, actors }, assets }
}

type ActorWithAssetRef = {
  image: (ActorImage & { assetId?: string }) | null
}

/**
 * JSON.stringify replacer: write image as { assetId } when assetId is present.
 */
export function serializeSnapshotForDownload(snapshot: PersistedSnapshot): string {
  const built = buildSnapshot(snapshot.project, null, snapshot.savedAt)
  const raw = JSON.stringify(
    built,
    (key, value) => {
      if (
        key === 'image' &&
        value &&
        typeof value === 'object' &&
        'assetId' in value &&
        typeof (value as { assetId: unknown }).assetId === 'string'
      ) {
        return { assetId: (value as { assetId: string }).assetId }
      }
      return value
    },
    2,
  )
  if (raw.length > MAX_PROJECT_JSON_CHARS) {
    throw new Error(
      `Project is too large to save (${Math.round(raw.length / 1024)} KB). Remove or replace large images.`,
    )
  }
  return raw
}

function cloneProject(project: Project): Project {
  const size = resolveProjectStageSize(project)
  return withProjectStageSize(
    {
      version: 1,
      name: sanitizeProjectName(project.name) || DEFAULT_PROJECT_NAME,
      actors: project.actors.map((a) => cloneSceneActor(a)),
      playback: { ...project.playback },
      stageAspect: clampStageAspect(project.stageAspect),
      stageWidth: size.width,
      stageHeight: size.height,
    },
    size,
  )
}

export function createEmptyPersistableProject(
  stageAspect: number = DEFAULT_STAGE_ASPECT,
  name: string = DEFAULT_PROJECT_NAME,
): Project {
  const safeName = sanitizeProjectName(name) || DEFAULT_PROJECT_NAME
  const aspect = clampStageAspect(stageAspect)
  const size = compositionSizeFromAspect(aspect)
  return {
    version: 1,
    name: safeName,
    actors: [createSceneActor({ name: 'Actor 1' })],
    playback: { ...DEFAULT_PLAYBACK },
    stageAspect: aspect,
    stageWidth: size.width,
    stageHeight: size.height,
  }
}

export function snapshotHasAnimation(snapshot: PersistedSnapshot): boolean {
  return projectHasAnyRecording(snapshot.project)
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function asFiniteNumber(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null
}

function clamp01(value: number): number {
  return Math.min(1, Math.max(0, value))
}
